# Aegis Arena CLI

Local installable package for wallet onboarding, 0G Galileo testing, simulation runs, and web session sync.

## Build

```bash
pnpm --filter @aegis-arena/cli build
```

## Local install options

### Option A: Global link (fast dev loop)

```bash
pnpm --filter @aegis-arena/cli link:global
```

Then run:

```bash
aegis --help
```

### Option B: Local packed tarball

```bash
pnpm --filter @aegis-arena/cli pack:local
pnpm add -g .local-packages/aegis-arena-cli-0.1.0.tgz
```

## Wallet onboarding + web sync

```bash
aegis login safe --safe <safe_address> --mode browser
aegis login sync-web --base-url http://localhost:3000
```

For Galileo RPC (default):

```bash
https://evmrpc-testnet.0g.ai
```
